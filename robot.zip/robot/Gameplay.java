import java.util.ArrayList;
import java.util.Scanner;

public class Gameplay {

    // deklarasi gameplay
    int pilihan, inputRobot, inputTindakan, inputLawan;
    private ArrayList<Robot> robots = new ArrayList<>();
    Boolean cekCombine = false;
    Boolean ulang = true;
    private CentralBrain centralBrain = new CentralBrain("RobotCombine", "Titan", 1000, 1000, 5000);

    Scanner input = new Scanner(System.in);

    public static void main(String[] args) throws InterruptedException { // main method
        Gameplay gameplay = new Gameplay();
        gameplay.constructRobot();
        gameplay.menu();

    }

    public void menu() throws InterruptedException { // menu interaksi

        while (ulang) { // pengulangan tampilan menu

            System.out.println("---Selamat Datang di Game Robot---");
            System.out.println("--------------------------------");
            System.out.println("Pilih tindakan yang akan anda lakukan:");
            System.out.println("1. Infomasi Robot");
            System.out.println("2. Pilih Robot");
            System.out.println("3. Combine");
            System.out.println("4. Exit");

            pilihan = input.nextInt();

            switch (pilihan) {
                case 1:
                    informasiRobot();
                    break;

                case 2:
                    pilihRobot();
                    ulang = false;
                    break;

                case 3:
                    cekCombine = true;
                    ulang = false;
                    System.out.println(centralBrain.combine());
                    break;

                case 4:
                    System.out.println("---Terima Kasih telah bermain---");
                    ulang = false;
                    return;

                default:
                    System.out.println("Pilihan tidak terdapat dalam menu");

            }
        }

    }

    public void informasiRobot() throws InterruptedException {
        System.out.println();

        for (Robot robot : robots) { // for each robot untuk informasi robot
            System.out.print(String.format("Nama: %s \n", robot.getName()));
            System.out.print(String.format("Type: %s \n", robot.getType()));
            System.out.print(String.format("Health: %s \n", robot.getHealth()));
            System.out.print(String.format("MaxHealth: %s \n", robot.getMaxHealth()));
            System.out.print(String.format("Power: %s \n \n", robot.getPower()));

            Thread.sleep(1000); // delay seperti arduino

        }

    }

    public void pilihRobot() {
        System.out.println();

        System.out.println("---Pilihan Robot---");

        int i = 1; // penomoran

        for (Robot robot : robots) { // for each robot untuk informasi robot
            System.out.print(String.format(i + ". Nama: %s ", robot.getName()));
            System.out.print(String.format("Type: %s ", robot.getType()));
            System.out.print(String.format("Health: %s ", robot.getHealth()));
            System.out.print(String.format("MaxHealth: %s ", robot.getMaxHealth()));
            System.out.print(String.format("Power: %s \n", robot.getPower()));

            i++;
        }

        System.out.println();
        System.out.println("Masukkan pilihan anda:");
        inputRobot = input.nextInt();

        System.out.println();
        System.out.println("Pilih Lawan:");

        int j = 1;

        for (i = 0; i < 5; i++) {

            if (inputRobot - 1 == i) {
                continue; // agar robot yang dipilih tidak menjadi lawan
            }

            System.out.println(String.format(j + ". Nama: %s ", robots.get(i).getName())); // sout lawan
            j++;

        }

        inputLawan = input.nextInt();

        System.out.println();
        System.out.println("Pilih Tindakan:");
        System.out.println("1. Attack");
        System.out.println("2. Defend");
        System.out.println("3. Heal");
        System.out.println("4. Skill 1");
        System.out.println("5. Skill 2");
        System.out.println("6. Skill 3");
        System.out.println("7. Ultimate Skill");
        inputTindakan = input.nextInt();
        System.out.println();

        double tangkis = 0;
        double heal = 0;

        switch (inputTindakan) {

            case 1:
                robots.get(inputRobot - 1).attack(); // robotpilihan perintah attack
                System.out.println(String.format("Robot %s melakukan attack ke robot %s dengan damage sebesar %s",
                        robots.get(inputRobot).getName(), robots.get(inputLawan).getName(),
                        robots.get(inputRobot).getPower()));
                break;

            case 2:
                tangkis = robots.get(inputRobot - 1).defend(robots.get(inputLawan)); // robotpilihan perintah defend
                System.out.println(String.format(
                        "Robot %s melakukan defense terhadap robot %s dengan pengurangan damage sebesar %s",
                        robots.get(inputRobot).getName(), robots.get(inputLawan).getName(), tangkis));
                break;

            case 3:
                heal = robots.get(inputRobot - 1).heal(); // robotpilihan perintah heal
                System.out.println(String.format("Robot %s melakukan heal sebesar %s",
                        robots.get(inputRobot).getName(), heal));
                break;

            case 4:
                System.out.println(robots.get(inputRobot).skill1()); // robotpilihan perintah menggunakan skill1

                break;

            case 5:
                System.out.println(robots.get(inputRobot).skill2()); // robotpilihan perintah menggunakan skill2

                break;

            case 6:
                System.out.println(robots.get(inputRobot).skill3()); // robotpilihan perintah menggunakan skill3

                break;

            case 7:
                System.out.println(robots.get(inputRobot).ultimate()); // robotpilihan perintah menggunakan ultimate

                break;

            default:
                System.out.println("Pilihan tidak terdapat dalam menu"); //
                ulang = true;
                break;

        }

    }

    public void constructRobot() {
        // deklarasi weapon
        Melee melee1 = new Melee("Ucil", "Melee", 60, 60, 25);
        Melee melee2 = new Melee("Asep", "Melee", 65, 65, 21);
        Ranged ranged1 = new Ranged("Badang", "Ranged", 40, 40, 35);
        Ranged ranged2 = new Ranged("Bading", "Ranged", 35, 35, 40);
        Support support = new Support("Badung", "Support", 100, 100, 12);

        robots.add(melee1);
        robots.add(melee2);
        robots.add(ranged1);
        robots.add(ranged2);
        robots.add(support);

    }

}
