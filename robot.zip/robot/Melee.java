public class Melee extends Robot {

    // constructor Melee
    Melee(String name, String type, int health, int maxHealth, int power) {
        super(name, type, health, maxHealth, power);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String skill1() { // method skill1
        return String.format("%s Menggunakan Skill 1 Tamparan Anak Kecil", getName());
    }

    @Override
    public String skill2() { // method skill2
        return String.format("%s Menggunakan Skill 2 Tamparan Remaja", getName());
    }

    @Override
    public String skill3() { // method skill3
        return String.format("%s Menggunakan Skill 3 Tamparan Dewasa", getName());
    }

    @Override
    public String ultimate() { // method ultimate
        return String.format("%s Menggunakan Skill Ultimate Tendangan Maut", getName());
    }
}
