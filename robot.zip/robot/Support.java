public class Support extends Robot {

    // constructor Support
    Support(String name, String type, int health, int maxHealth, int power) {
        super(name, type, health, maxHealth, power);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String skill1() { // method skill1
        return String.format("%s Menggunakan Skill 1 Rafaela", getName());
    }

    @Override
    public String skill2() { // method skill2
        return String.format("%s Menggunakan Skill 2 Faramis", getName());
    }

    @Override
    public String skill3() { // method skill3
        return String.format("%s Menggunakan Skill 3 Vexana", getName());
    }

    @Override
    public String ultimate() { // method ultimate
        return String.format("%s Menggunakan Ultimate Harry Potter", getName());
    }

}
