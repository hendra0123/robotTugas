
public abstract class Robot {

    // deklarasi robot
    private String name;
    private String type;
    private double health;
    private int maxHealth;
    private int power;
    private double tangkis;
    private double heal;

    // constructor robot
    Robot(String name, String type, int health, int maxHealth, int power) {
        this.name = name;
        this.type = type;
        this.health = health;
        this.maxHealth = maxHealth;
        this.power = power;
    }

    public String getName() { // get name
        return name;
    }

    public String getType() { // get type
        return type;
    }

    public double getHealth() { // get health
        return health;
    }

    public int getMaxHealth() { // get max health
        return maxHealth;
    }

    public void move() { // move robot

    }

    public int getPower() { // get power
        return power;
    }

    public void attack() { // menyerang

    }

    public double defend(Robot robots) { // defends robot
        tangkis = 0.1 * robots.getPower();
        return tangkis;
    }

    public double heal() { // heal robot
        heal = 0.5 * maxHealth;
        return heal;

    }

    public abstract String skill1(); // buat panggil skill 1

    public abstract String skill2(); // buat panggil skill 2

    public abstract String skill3(); // buat panggil skill 3

    public abstract String ultimate(); // buat panggil ultimate

}
