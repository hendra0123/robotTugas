public interface CombiningRobot {

    public String combine(); // interface combine

    public String separate(); // interface separate

}
