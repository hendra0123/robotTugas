public class CentralBrain extends Robot implements CombiningRobot {

    // constructor CentralBrain
    CentralBrain(String name, String type, int health, int maxHealth, int power) {
        super(name, type, health, maxHealth, power);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String combine() { // combine robot besar
        // TODO Auto-generated method stub
        return String.format("Robot telah bergabung", null);
    }

    @Override
    public String separate() { // separate robot besar
        // TODO Auto-generated method stub
        return String.format("Robot kembali berpisah", null);
    }

    @Override
    public String skill1() { // menggunakan skill1
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'skill1'");
    }

    @Override
    public String skill2() { // menggunakan skill2
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'skill2'");
    }

    @Override
    public String skill3() { // menggunaan skill3
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'skill3'");
    }

    @Override
    public String ultimate() { // menggunakan ultimate
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ultimate'");
    }

}
